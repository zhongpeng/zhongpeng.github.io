import {build} from 'esbuild';
import {readFile,writeFile,mkdir,readdir,cp} from 'node:fs/promises';
import path from 'node:path';
async function files(dir){const list=await readdir(dir,{withFileTypes:true});return (await Promise.all(list.map(f=>f.isDirectory()?files(path.join(dir,f.name)):[path.join(dir,f.name)]))).flat();}
const result=await build({entryPoints:['scripts/standalone.tsx'],bundle:true,minify:true,write:false,platform:'browser',format:'iife',jsx:'automatic',tsconfig:'tsconfig.json',define:{'process.env.NODE_ENV':'"production"'}});
const cssFiles=(await files('dist/client')).filter(x=>x.endsWith('.css'));
let css=(await Promise.all(cssFiles.map(f=>readFile(f,'utf8')))).join('\n');
// The standalone artifact uses system fonts and needs no external font requests.
css=css.replace(/@font-face\s*\{[^}]*\}/g,'');
const js=result.outputFiles[0].text.replace(/<\/script/gi,'<\\/script');
await mkdir('out',{recursive:true});
await writeFile('out/index.html',`<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="theme-color" content="#142f5b"><title>有数 · 个人财务助手</title><meta name="description" content="手机优先的个人财务交互原型，仅演示数据"><style>${css}</style></head><body><div id="app"></div><script>${js}</script></body></html>`);
await cp('public/ocr','out/ocr',{recursive:true});
console.log('Static site built: out/index.html and self-hosted OCR assets');
