import test from 'node:test';import assert from 'node:assert/strict';import{parseRows,appendBatch}from'../lib/ocr-batch.mjs';import{totals}from'../lib/finance.mjs';
test('信用卡逐笔拆分，积分忽略，短年份及退款独立',()=>{const r=parseRows('个人信用卡\n示例商店 ¥12.00\n[消费] +60积分\n26/09/07\n示例地铁\n¥3.00\n[消费] +15积分\n26/09/06\n示例商店 ¥-2.00\n[退款] -10积分\n26/09/05');assert.equal(r.length,3);assert.deepEqual(r.map(x=>x.amount),['12.00','3.00','2.00']);assert.equal(r[1].date,'2026-09-06');assert.equal(r[2].kind,'refund')});
test('同图同笔批量重复提交不增加记录',()=>{const b=[{id:'a'},{id:'b'}];assert.equal(appendBatch(appendBatch([],b),b).length,2)});
test('信用卡支出增加负债，不减少现金',()=>{const a=totals([],[],0,100000,0),b=totals([{type:'expense',amount:1000,account:'信用卡（演示）'}],[],0,100000,0);assert.equal(a.cash,b.cash);assert.equal(b.debt-a.debt,1000);assert.equal(b.expenses,1000)});

test('订单卡片保留商户和消费/下单时间',()=>{const rows=parseRows('示例酒吧 > 待评价\n套餐 ¥129\n消费时间: 2026-09-07\n示例粉面馆 > 已完成\n¥22.3\n下单时间: 2026-08-30 12:26');assert.equal(rows.length,2);assert.equal(rows[0].title,'示例酒吧');assert.equal(rows[0].timeKind,'消费时间');assert.equal(rows[1].title,'示例粉面馆');assert.equal(rows[1].time,'12:26');assert.equal(rows[1].date,'2026-08-30')});
