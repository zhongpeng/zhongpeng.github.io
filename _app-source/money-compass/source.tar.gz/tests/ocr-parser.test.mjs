import test from 'node:test';import assert from 'node:assert/strict';import {parseBill} from '../lib/ocr-parser.mjs';
test('从支付字段提取金额，不把订单号当金额',()=>{const p=parseBill('支付金额 ￥35.00\n2026年9月9日\n订单号 123456789012345\n商户：午餐店');assert.deepEqual(p.amounts,[3500]);assert.equal(p.date,'2026-09-09');assert.equal(p.title,'午餐店')});
test('多个金额不静默选最大值',()=>assert.deepEqual(parseBill('原价 ￥100.00\n实付 ￥80.00').amounts,[10000,8000]));
test('无效日期、余额、退款保守处理',()=>{assert.equal(parseBill('2026-13-45').date,'');assert.equal(parseBill('余额 ￥500.00 退款').caution,true)});

test('真实 OCR 输出空格和日期数字不产生伪金额',()=>assert.deepEqual(parseBill('支付金额 ¥ 35.00\n2026-09-09 12:30').amounts,[3500]));

test('收支正负号与文字预选',()=>{assert.equal(parseBill('+35.00').kind,'income');assert.equal(parseBill('− ¥35.00').kind,'expense');assert.equal(parseBill('支付成功 ¥35.00').kind,'expense');assert.equal(parseBill('收入 +100.00 支出 -20.00').kind,'');assert.equal(parseBill('退款 +35.00').kind,'transfer');assert.equal(parseBill('2026-09-09').kind,'');});
