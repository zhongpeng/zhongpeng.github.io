import test from 'node:test';
import assert from 'node:assert/strict';
import {dueDate,reminderAt,appendRecurring,calendarFile} from '../lib/recurring.mjs';
const r={id:'rent',name:'房租',amount:200000,day:5,time:'09:30',advance:1,category:'居住',account:'银行卡',bookId:'daily'};
test('短月与闰年月末',()=>{assert.equal(dueDate('2026-02',31),'2026-02-28');assert.equal(dueDate('2028-02',31),'2028-02-29');assert.equal(dueDate('2026-09',31),'2026-09-30')});
test('北京时间提醒跨月提前',()=>{assert.equal(reminderAt('2026-09',1,'09:30',1),Date.parse('2026-08-31T01:30:00Z'))});
test('同月确认幂等，移动归属后也不重复，下月独立',()=>{const first=appendRecurring([],r,'2026-09');const moved=first.map(e=>({...e,bookId:'travel'}));assert.equal(appendRecurring(moved,r,'2026-09').length,1);assert.equal(appendRecurring(moved,r,'2026-10').length,2);assert.equal(first[0].amount,200000)});
test('日历每月重复，明确时区和提前提醒',()=>{const s=calendarFile(r,'2026-09');assert.match(s,/DTSTART;TZID=Asia\/Shanghai:20260905T093000/);assert.match(s,/BYMONTHDAY=5,-1;BYSETPOS=1/);assert.match(s,/TRIGGER:-P1D/);assert.match(s,/END:VCALENDAR\r\n$/)});

test('固定收入按收入入账',()=>{assert.equal(appendRecurring([],{...r,type:'income'},'2026-09')[0].type,'income')});
